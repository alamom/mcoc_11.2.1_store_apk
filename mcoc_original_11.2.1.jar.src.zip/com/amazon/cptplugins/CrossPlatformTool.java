package com.amazon.cptplugins;

public enum CrossPlatformTool
{
  AIR,  CORDOVA,  UNITY,  XAMARIN;
  
  private CrossPlatformTool() {}
}


/* Location:              C:\tools\androidhack\com.kabam.marvelbattle\classes.jar!\com\amazon\cptplugins\CrossPlatformTool.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */