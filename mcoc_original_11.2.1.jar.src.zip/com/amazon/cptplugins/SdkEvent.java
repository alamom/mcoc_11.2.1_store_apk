package com.amazon.cptplugins;

public abstract interface SdkEvent {}


/* Location:              C:\tools\androidhack\com.kabam.marvelbattle\classes.jar!\com\amazon\cptplugins\SdkEvent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */