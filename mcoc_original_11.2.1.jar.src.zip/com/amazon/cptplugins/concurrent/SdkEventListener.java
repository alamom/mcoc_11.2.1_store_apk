package com.amazon.cptplugins.concurrent;

public abstract interface SdkEventListener
{
  public abstract void fireSdkEvent(String paramString);
}


/* Location:              C:\tools\androidhack\com.kabam.marvelbattle\classes.jar!\com\amazon\cptplugins\concurrent\SdkEventListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */